--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;

ALTER TABLE ONLY public.twitter_tweet DROP CONSTRAINT twitter_tweet_query_id_bd42b699_fk_twitter_query_id;
ALTER TABLE ONLY public.resume_skill DROP CONSTRAINT resume_skill_skillset_id_c155f55d_fk_resume_skillset_id;
ALTER TABLE ONLY public.resume_project DROP CONSTRAINT resume_project_projtype_id_36ffa15d_fk_resume_projecttype_id;
ALTER TABLE ONLY public.programminglanguage DROP CONSTRAINT progra_programmingarea_id_1edf0110_fk_resume_programmingarea_id;
ALTER TABLE ONLY public.pages_richtextpage DROP CONSTRAINT pages_richtextpage_page_ptr_id_8ca99b83_fk_pages_page_id;
ALTER TABLE ONLY public.pages_page DROP CONSTRAINT pages_page_site_id_47a43e5b_fk_django_site_id;
ALTER TABLE ONLY public.pages_page DROP CONSTRAINT pages_page_parent_id_133fa4d3_fk_pages_page_id;
ALTER TABLE ONLY public.pages_link DROP CONSTRAINT pages_link_page_ptr_id_37d469f7_fk_pages_page_id;
ALTER TABLE ONLY public.jobaccomplishment DROP CONSTRAINT jobaccomplishment_job_id_a04554fd_fk_jobs_id;
ALTER TABLE ONLY public.generic_threadedcomment DROP CONSTRAINT generic_threadedc_comment_ptr_id_e208ed60_fk_django_comments_id;
ALTER TABLE ONLY public.generic_rating DROP CONSTRAINT generic_rating_user_id_60020469_fk_auth_user_id;
ALTER TABLE ONLY public.generic_rating DROP CONSTRAINT generic_rati_content_type_id_eaf475fa_fk_django_content_type_id;
ALTER TABLE ONLY public.generic_keyword DROP CONSTRAINT generic_keyword_site_id_c5be0acc_fk_django_site_id;
ALTER TABLE ONLY public.generic_assignedkeyword DROP CONSTRAINT generic_assignedkeywo_keyword_id_44c17f9d_fk_generic_keyword_id;
ALTER TABLE ONLY public.generic_assignedkeyword DROP CONSTRAINT generic_assi_content_type_id_3dd89a7f_fk_django_content_type_id;
ALTER TABLE ONLY public.galleries_gallery DROP CONSTRAINT galleries_gallery_page_ptr_id_8562ba87_fk_pages_page_id;
ALTER TABLE ONLY public.galleries_galleryimage DROP CONSTRAINT galleries__gallery_id_af12d3f5_fk_galleries_gallery_page_ptr_id;
ALTER TABLE ONLY public.forms_formentry DROP CONSTRAINT forms_formentry_form_id_d0f23912_fk_forms_form_page_ptr_id;
ALTER TABLE ONLY public.forms_form DROP CONSTRAINT forms_form_page_ptr_id_d3bcbf3a_fk_pages_page_id;
ALTER TABLE ONLY public.forms_fieldentry DROP CONSTRAINT forms_fieldentry_entry_id_c4fdc570_fk_forms_formentry_id;
ALTER TABLE ONLY public.forms_field DROP CONSTRAINT forms_field_form_id_9ca5dc7e_fk_forms_form_page_ptr_id;
ALTER TABLE ONLY public.django_redirect DROP CONSTRAINT django_redirect_site_id_c3e37341_fk_django_site_id;
ALTER TABLE ONLY public.django_comments DROP CONSTRAINT django_comments_user_id_a0a440a1_fk_auth_user_id;
ALTER TABLE ONLY public.django_comments DROP CONSTRAINT django_comments_site_id_9dcf666e_fk_django_site_id;
ALTER TABLE ONLY public.django_comment_flags DROP CONSTRAINT django_comment_flags_user_id_f3f81f0a_fk_auth_user_id;
ALTER TABLE ONLY public.django_comment_flags DROP CONSTRAINT django_comment_flags_comment_id_d8054933_fk_django_comments_id;
ALTER TABLE ONLY public.django_comments DROP CONSTRAINT django_comme_content_type_id_c4afe962_fk_django_content_type_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id;
ALTER TABLE ONLY public.core_sitepermission DROP CONSTRAINT core_sitepermission_user_id_0a3cbb11_fk_auth_user_id;
ALTER TABLE ONLY public.core_sitepermission_sites DROP CONSTRAINT core_sitepermission_sites_site_id_38038b76_fk_django_site_id;
ALTER TABLE ONLY public.core_sitepermission_sites DROP CONSTRAINT core_sitep_sitepermission_id_d33bc79e_fk_core_sitepermission_id;
ALTER TABLE ONLY public.conf_setting DROP CONSTRAINT conf_setting_site_id_b235f7ed_fk_django_site_id;
ALTER TABLE ONLY public.categories_category DROP CONSTRAINT categories_categor_parent_id_f141de59_fk_categories_category_id;
ALTER TABLE ONLY public.categories_categoryrelation DROP CONSTRAINT categories_categ_category_id_e5e686b2_fk_categories_category_id;
ALTER TABLE ONLY public.categories_categoryrelation DROP CONSTRAINT categories_c_content_type_id_f686b696_fk_django_content_type_id;
ALTER TABLE ONLY public.blog_blogpost DROP CONSTRAINT blog_blogpost_user_id_12ed6b16_fk_auth_user_id;
ALTER TABLE ONLY public.blog_blogpost DROP CONSTRAINT blog_blogpost_site_id_7995688f_fk_django_site_id;
ALTER TABLE ONLY public.blog_blogpost_related_posts DROP CONSTRAINT blog_blogpost_relat_to_blogpost_id_35f7acdd_fk_blog_blogpost_id;
ALTER TABLE ONLY public.blog_blogpost_related_posts DROP CONSTRAINT blog_blogpost_rel_from_blogpost_id_27ea4c18_fk_blog_blogpost_id;
ALTER TABLE ONLY public.blog_blogpost_categories DROP CONSTRAINT blog_blogpost_categori_blogpost_id_daeea608_fk_blog_blogpost_id;
ALTER TABLE ONLY public.blog_blogpost_categories DROP CONSTRAINT blog_blogpost__blogcategory_id_f6695246_fk_blog_blogcategory_id;
ALTER TABLE ONLY public.blog_blogcategory DROP CONSTRAINT blog_blogcategory_site_id_42b9c96d_fk_django_site_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id;
ALTER TABLE ONLY public.generic_threadedcomment DROP CONSTRAINT ad11d0c1662f6ed6839bc6d43c9ce4f3;
DROP INDEX public.twitter_tweet_0bbeda9c;
DROP INDEX public.resume_skill_3b232a2a;
DROP INDEX public.resume_project_68d8cccf;
DROP INDEX public.programminglanguage_51d2fd4b;
DROP INDEX public.pages_page_publish_date_eb7c8d46_uniq;
DROP INDEX public.pages_page_9365d6e7;
DROP INDEX public.pages_page_6be37982;
DROP INDEX public.jobaccomplishment_d697ea38;
DROP INDEX public.generic_threadedcomment_21ce1e68;
DROP INDEX public.generic_rating_e8701ad4;
DROP INDEX public.generic_rating_417f1b1c;
DROP INDEX public.generic_keyword_9365d6e7;
DROP INDEX public.generic_assignedkeyword_5c003bba;
DROP INDEX public.generic_assignedkeyword_417f1b1c;
DROP INDEX public.galleries_galleryimage_6d994cdb;
DROP INDEX public.forms_formentry_d6cba1ad;
DROP INDEX public.forms_fieldentry_b64a62ea;
DROP INDEX public.forms_field_d6cba1ad;
DROP INDEX public.django_site_domain_a2e37b91_like;
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_de54fa62;
DROP INDEX public.django_redirect_old_path_c6cc94d3_like;
DROP INDEX public.django_redirect_9365d6e7;
DROP INDEX public.django_redirect_91a0b591;
DROP INDEX public.django_comments_submit_date_514ed2d9_uniq;
DROP INDEX public.django_comments_e8701ad4;
DROP INDEX public.django_comments_9365d6e7;
DROP INDEX public.django_comments_417f1b1c;
DROP INDEX public.django_comment_flags_flag_8b141fcb_like;
DROP INDEX public.django_comment_flags_e8701ad4;
DROP INDEX public.django_comment_flags_69b97d17;
DROP INDEX public.django_comment_flags_327a6c43;
DROP INDEX public.django_admin_log_e8701ad4;
DROP INDEX public.django_admin_log_417f1b1c;
DROP INDEX public.core_sitepermission_sites_f6687ce4;
DROP INDEX public.core_sitepermission_sites_9365d6e7;
DROP INDEX public.conf_setting_9365d6e7;
DROP INDEX public.categories_categoryrelation_b583a629;
DROP INDEX public.categories_categoryrelation_417f1b1c;
DROP INDEX public.categories_category_slug_6fddebb1_like;
DROP INDEX public.categories_category_caf7cc51;
DROP INDEX public.categories_category_c9e9a848;
DROP INDEX public.categories_category_6be37982;
DROP INDEX public.categories_category_656442a0;
DROP INDEX public.categories_category_3cfbd988;
DROP INDEX public.categories_category_2dbcba41;
DROP INDEX public.blog_blogpost_related_posts_71f16e58;
DROP INDEX public.blog_blogpost_related_posts_191c4981;
DROP INDEX public.blog_blogpost_publish_date_703abc16_uniq;
DROP INDEX public.blog_blogpost_e8701ad4;
DROP INDEX public.blog_blogpost_categories_efb54956;
DROP INDEX public.blog_blogpost_categories_53a0aca2;
DROP INDEX public.blog_blogpost_9365d6e7;
DROP INDEX public.blog_blogcategory_9365d6e7;
DROP INDEX public.auth_user_username_6821ab7c_like;
DROP INDEX public.auth_user_user_permissions_e8701ad4;
DROP INDEX public.auth_user_user_permissions_8373b171;
DROP INDEX public.auth_user_groups_e8701ad4;
DROP INDEX public.auth_user_groups_0e939a4f;
DROP INDEX public.auth_permission_417f1b1c;
DROP INDEX public.auth_group_permissions_8373b171;
DROP INDEX public.auth_group_permissions_0e939a4f;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.twitter_tweet DROP CONSTRAINT twitter_tweet_pkey;
ALTER TABLE ONLY public.twitter_query DROP CONSTRAINT twitter_query_pkey;
ALTER TABLE ONLY public.resume_skillset DROP CONSTRAINT resume_skillset_pkey;
ALTER TABLE ONLY public.resume_skill DROP CONSTRAINT resume_skill_pkey;
ALTER TABLE ONLY public.resume_projecttype DROP CONSTRAINT resume_projecttype_pkey;
ALTER TABLE ONLY public.resume_project DROP CONSTRAINT resume_project_pkey;
ALTER TABLE ONLY public.resume_programmingarea DROP CONSTRAINT resume_programmingarea_pkey;
ALTER TABLE ONLY public.resume_personalinfo DROP CONSTRAINT resume_personalinfo_pkey;
ALTER TABLE ONLY public.resume_overview DROP CONSTRAINT resume_overview_pkey;
ALTER TABLE ONLY public.resume_language DROP CONSTRAINT resume_language_pkey;
ALTER TABLE ONLY public.resume_education DROP CONSTRAINT resume_education_pkey;
ALTER TABLE ONLY public.publications DROP CONSTRAINT publications_pkey;
ALTER TABLE ONLY public.programminglanguage DROP CONSTRAINT programminglanguage_pkey;
ALTER TABLE ONLY public.pages_richtextpage DROP CONSTRAINT pages_richtextpage_pkey;
ALTER TABLE ONLY public.pages_page DROP CONSTRAINT pages_page_pkey;
ALTER TABLE ONLY public.pages_link DROP CONSTRAINT pages_link_pkey;
ALTER TABLE ONLY public.jobs DROP CONSTRAINT jobs_pkey;
ALTER TABLE ONLY public.jobaccomplishment DROP CONSTRAINT jobaccomplishment_pkey;
ALTER TABLE ONLY public.generic_threadedcomment DROP CONSTRAINT generic_threadedcomment_pkey;
ALTER TABLE ONLY public.generic_rating DROP CONSTRAINT generic_rating_pkey;
ALTER TABLE ONLY public.generic_keyword DROP CONSTRAINT generic_keyword_pkey;
ALTER TABLE ONLY public.generic_assignedkeyword DROP CONSTRAINT generic_assignedkeyword_pkey;
ALTER TABLE ONLY public.galleries_galleryimage DROP CONSTRAINT galleries_galleryimage_pkey;
ALTER TABLE ONLY public.galleries_gallery DROP CONSTRAINT galleries_gallery_pkey;
ALTER TABLE ONLY public.forms_formentry DROP CONSTRAINT forms_formentry_pkey;
ALTER TABLE ONLY public.forms_form DROP CONSTRAINT forms_form_pkey;
ALTER TABLE ONLY public.forms_fieldentry DROP CONSTRAINT forms_fieldentry_pkey;
ALTER TABLE ONLY public.forms_field DROP CONSTRAINT forms_field_pkey;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_pkey;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_domain_a2e37b91_uniq;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_redirect DROP CONSTRAINT django_redirect_site_id_ac5dd16b_uniq;
ALTER TABLE ONLY public.django_redirect DROP CONSTRAINT django_redirect_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_comments DROP CONSTRAINT django_comments_pkey;
ALTER TABLE ONLY public.django_comment_flags DROP CONSTRAINT django_comment_flags_user_id_537f77a7_uniq;
ALTER TABLE ONLY public.django_comment_flags DROP CONSTRAINT django_comment_flags_pkey;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.core_sitepermission DROP CONSTRAINT core_sitepermission_user_id_key;
ALTER TABLE ONLY public.core_sitepermission_sites DROP CONSTRAINT core_sitepermission_sites_sitepermission_id_e3e7353a_uniq;
ALTER TABLE ONLY public.core_sitepermission_sites DROP CONSTRAINT core_sitepermission_sites_pkey;
ALTER TABLE ONLY public.core_sitepermission DROP CONSTRAINT core_sitepermission_pkey;
ALTER TABLE ONLY public.conf_setting DROP CONSTRAINT conf_setting_pkey;
ALTER TABLE ONLY public.categories_categoryrelation DROP CONSTRAINT categories_categoryrelation_pkey;
ALTER TABLE ONLY public.categories_category DROP CONSTRAINT categories_category_pkey;
ALTER TABLE ONLY public.categories_category DROP CONSTRAINT categories_category_parent_id_893f7987_uniq;
ALTER TABLE ONLY public.blog_blogpost_related_posts DROP CONSTRAINT blog_blogpost_related_posts_pkey;
ALTER TABLE ONLY public.blog_blogpost_related_posts DROP CONSTRAINT blog_blogpost_related_posts_from_blogpost_id_3bd0f49f_uniq;
ALTER TABLE ONLY public.blog_blogpost DROP CONSTRAINT blog_blogpost_pkey;
ALTER TABLE ONLY public.blog_blogpost_categories DROP CONSTRAINT blog_blogpost_categories_pkey;
ALTER TABLE ONLY public.blog_blogpost_categories DROP CONSTRAINT blog_blogpost_categories_blogpost_id_a64d32c5_uniq;
ALTER TABLE ONLY public.blog_blogcategory DROP CONSTRAINT blog_blogcategory_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_94350c0c_uniq;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE ONLY public.achievement DROP CONSTRAINT achievement_pkey;
ALTER TABLE public.twitter_tweet ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.twitter_query ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resume_skillset ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resume_skill ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resume_projecttype ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resume_project ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resume_programmingarea ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resume_personalinfo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resume_overview ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resume_language ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resume_education ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.publications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.programminglanguage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.pages_page ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.jobs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.jobaccomplishment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.generic_rating ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.generic_keyword ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.generic_assignedkeyword ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.galleries_galleryimage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.forms_formentry ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.forms_fieldentry ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.forms_field ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_site ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_redirect ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_comment_flags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.core_sitepermission_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.core_sitepermission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.conf_setting ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.categories_categoryrelation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.categories_category ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_blogpost_related_posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_blogpost_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_blogpost ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_blogcategory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.achievement ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.twitter_tweet_id_seq;
DROP TABLE public.twitter_tweet;
DROP SEQUENCE public.twitter_query_id_seq;
DROP TABLE public.twitter_query;
DROP SEQUENCE public.resume_skillset_id_seq;
DROP TABLE public.resume_skillset;
DROP SEQUENCE public.resume_skill_id_seq;
DROP TABLE public.resume_skill;
DROP SEQUENCE public.resume_projecttype_id_seq;
DROP TABLE public.resume_projecttype;
DROP SEQUENCE public.resume_project_id_seq;
DROP TABLE public.resume_project;
DROP SEQUENCE public.resume_programmingarea_id_seq;
DROP TABLE public.resume_programmingarea;
DROP SEQUENCE public.resume_personalinfo_id_seq;
DROP TABLE public.resume_personalinfo;
DROP SEQUENCE public.resume_overview_id_seq;
DROP TABLE public.resume_overview;
DROP SEQUENCE public.resume_language_id_seq;
DROP TABLE public.resume_language;
DROP SEQUENCE public.resume_education_id_seq;
DROP TABLE public.resume_education;
DROP SEQUENCE public.publications_id_seq;
DROP TABLE public.publications;
DROP SEQUENCE public.programminglanguage_id_seq;
DROP TABLE public.programminglanguage;
DROP TABLE public.pages_richtextpage;
DROP SEQUENCE public.pages_page_id_seq;
DROP TABLE public.pages_page;
DROP TABLE public.pages_link;
DROP SEQUENCE public.jobs_id_seq;
DROP TABLE public.jobs;
DROP SEQUENCE public.jobaccomplishment_id_seq;
DROP TABLE public.jobaccomplishment;
DROP TABLE public.generic_threadedcomment;
DROP SEQUENCE public.generic_rating_id_seq;
DROP TABLE public.generic_rating;
DROP SEQUENCE public.generic_keyword_id_seq;
DROP TABLE public.generic_keyword;
DROP SEQUENCE public.generic_assignedkeyword_id_seq;
DROP TABLE public.generic_assignedkeyword;
DROP SEQUENCE public.galleries_galleryimage_id_seq;
DROP TABLE public.galleries_galleryimage;
DROP TABLE public.galleries_gallery;
DROP SEQUENCE public.forms_formentry_id_seq;
DROP TABLE public.forms_formentry;
DROP TABLE public.forms_form;
DROP SEQUENCE public.forms_fieldentry_id_seq;
DROP TABLE public.forms_fieldentry;
DROP SEQUENCE public.forms_field_id_seq;
DROP TABLE public.forms_field;
DROP SEQUENCE public.django_site_id_seq;
DROP TABLE public.django_site;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_redirect_id_seq;
DROP TABLE public.django_redirect;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_comments_id_seq;
DROP TABLE public.django_comments;
DROP SEQUENCE public.django_comment_flags_id_seq;
DROP TABLE public.django_comment_flags;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.core_sitepermission_sites_id_seq;
DROP TABLE public.core_sitepermission_sites;
DROP SEQUENCE public.core_sitepermission_id_seq;
DROP TABLE public.core_sitepermission;
DROP SEQUENCE public.conf_setting_id_seq;
DROP TABLE public.conf_setting;
DROP SEQUENCE public.categories_categoryrelation_id_seq;
DROP TABLE public.categories_categoryrelation;
DROP SEQUENCE public.categories_category_id_seq;
DROP TABLE public.categories_category;
DROP SEQUENCE public.blog_blogpost_related_posts_id_seq;
DROP TABLE public.blog_blogpost_related_posts;
DROP SEQUENCE public.blog_blogpost_id_seq;
DROP SEQUENCE public.blog_blogpost_categories_id_seq;
DROP TABLE public.blog_blogpost_categories;
DROP TABLE public.blog_blogpost;
DROP SEQUENCE public.blog_blogcategory_id_seq;
DROP TABLE public.blog_blogcategory;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP SEQUENCE public.achievement_id_seq;
DROP TABLE public.achievement;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: achievement; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.achievement (
    id integer NOT NULL,
    description text NOT NULL,
    "order" integer NOT NULL,
    url character varying(200) NOT NULL,
    title character varying(50) NOT NULL
);


ALTER TABLE public.achievement OWNER TO amarin;

--
-- Name: achievement_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.achievement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.achievement_id_seq OWNER TO amarin;

--
-- Name: achievement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.achievement_id_seq OWNED BY public.achievement.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO amarin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO amarin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO amarin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO amarin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO amarin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO amarin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO amarin;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO amarin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO amarin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO amarin;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO amarin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO amarin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: blog_blogcategory; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.blog_blogcategory (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    site_id integer NOT NULL
);


ALTER TABLE public.blog_blogcategory OWNER TO amarin;

--
-- Name: blog_blogcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.blog_blogcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_blogcategory_id_seq OWNER TO amarin;

--
-- Name: blog_blogcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.blog_blogcategory_id_seq OWNED BY public.blog_blogcategory.id;


--
-- Name: blog_blogpost; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.blog_blogpost (
    id integer NOT NULL,
    comments_count integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    rating_count integer NOT NULL,
    rating_sum integer NOT NULL,
    rating_average double precision NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    allow_comments boolean NOT NULL,
    featured_image character varying(255),
    site_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.blog_blogpost OWNER TO amarin;

--
-- Name: blog_blogpost_categories; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.blog_blogpost_categories (
    id integer NOT NULL,
    blogpost_id integer NOT NULL,
    blogcategory_id integer NOT NULL
);


ALTER TABLE public.blog_blogpost_categories OWNER TO amarin;

--
-- Name: blog_blogpost_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.blog_blogpost_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_blogpost_categories_id_seq OWNER TO amarin;

--
-- Name: blog_blogpost_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.blog_blogpost_categories_id_seq OWNED BY public.blog_blogpost_categories.id;


--
-- Name: blog_blogpost_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.blog_blogpost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_blogpost_id_seq OWNER TO amarin;

--
-- Name: blog_blogpost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.blog_blogpost_id_seq OWNED BY public.blog_blogpost.id;


--
-- Name: blog_blogpost_related_posts; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.blog_blogpost_related_posts (
    id integer NOT NULL,
    from_blogpost_id integer NOT NULL,
    to_blogpost_id integer NOT NULL
);


ALTER TABLE public.blog_blogpost_related_posts OWNER TO amarin;

--
-- Name: blog_blogpost_related_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.blog_blogpost_related_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_blogpost_related_posts_id_seq OWNER TO amarin;

--
-- Name: blog_blogpost_related_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.blog_blogpost_related_posts_id_seq OWNED BY public.blog_blogpost_related_posts.id;


--
-- Name: categories_category; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.categories_category (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(50) NOT NULL,
    active boolean NOT NULL,
    thumbnail character varying(100),
    thumbnail_width integer,
    thumbnail_height integer,
    "order" integer NOT NULL,
    alternate_title character varying(100) NOT NULL,
    alternate_url character varying(200) NOT NULL,
    description text,
    meta_keywords character varying(255) NOT NULL,
    meta_extra text NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id integer,
    CONSTRAINT categories_category_level_check CHECK ((level >= 0)),
    CONSTRAINT categories_category_lft_check CHECK ((lft >= 0)),
    CONSTRAINT categories_category_rght_check CHECK ((rght >= 0)),
    CONSTRAINT categories_category_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.categories_category OWNER TO amarin;

--
-- Name: categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_category_id_seq OWNER TO amarin;

--
-- Name: categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.categories_category_id_seq OWNED BY public.categories_category.id;


--
-- Name: categories_categoryrelation; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.categories_categoryrelation (
    id integer NOT NULL,
    object_id integer NOT NULL,
    relation_type character varying(200),
    category_id integer NOT NULL,
    content_type_id integer NOT NULL,
    CONSTRAINT categories_categoryrelation_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE public.categories_categoryrelation OWNER TO amarin;

--
-- Name: categories_categoryrelation_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.categories_categoryrelation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_categoryrelation_id_seq OWNER TO amarin;

--
-- Name: categories_categoryrelation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.categories_categoryrelation_id_seq OWNED BY public.categories_categoryrelation.id;


--
-- Name: conf_setting; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.conf_setting (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    value character varying(2000) NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.conf_setting OWNER TO amarin;

--
-- Name: conf_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.conf_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.conf_setting_id_seq OWNER TO amarin;

--
-- Name: conf_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.conf_setting_id_seq OWNED BY public.conf_setting.id;


--
-- Name: core_sitepermission; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.core_sitepermission (
    id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.core_sitepermission OWNER TO amarin;

--
-- Name: core_sitepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.core_sitepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_sitepermission_id_seq OWNER TO amarin;

--
-- Name: core_sitepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.core_sitepermission_id_seq OWNED BY public.core_sitepermission.id;


--
-- Name: core_sitepermission_sites; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.core_sitepermission_sites (
    id integer NOT NULL,
    sitepermission_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.core_sitepermission_sites OWNER TO amarin;

--
-- Name: core_sitepermission_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.core_sitepermission_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_sitepermission_sites_id_seq OWNER TO amarin;

--
-- Name: core_sitepermission_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.core_sitepermission_sites_id_seq OWNED BY public.core_sitepermission_sites.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO amarin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO amarin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_comment_flags; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.django_comment_flags (
    id integer NOT NULL,
    flag character varying(30) NOT NULL,
    flag_date timestamp with time zone NOT NULL,
    comment_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.django_comment_flags OWNER TO amarin;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.django_comment_flags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_comment_flags_id_seq OWNER TO amarin;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.django_comment_flags_id_seq OWNED BY public.django_comment_flags.id;


--
-- Name: django_comments; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.django_comments (
    id integer NOT NULL,
    object_pk text NOT NULL,
    user_name character varying(50) NOT NULL,
    user_email character varying(254) NOT NULL,
    user_url character varying(200) NOT NULL,
    comment text NOT NULL,
    submit_date timestamp with time zone NOT NULL,
    ip_address inet,
    is_public boolean NOT NULL,
    is_removed boolean NOT NULL,
    content_type_id integer NOT NULL,
    site_id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.django_comments OWNER TO amarin;

--
-- Name: django_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.django_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_comments_id_seq OWNER TO amarin;

--
-- Name: django_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.django_comments_id_seq OWNED BY public.django_comments.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO amarin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO amarin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO amarin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO amarin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_redirect; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.django_redirect (
    id integer NOT NULL,
    site_id integer NOT NULL,
    old_path character varying(200) NOT NULL,
    new_path character varying(200) NOT NULL
);


ALTER TABLE public.django_redirect OWNER TO amarin;

--
-- Name: django_redirect_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.django_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_redirect_id_seq OWNER TO amarin;

--
-- Name: django_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.django_redirect_id_seq OWNED BY public.django_redirect.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO amarin;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO amarin;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO amarin;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: forms_field; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.forms_field (
    id integer NOT NULL,
    _order integer,
    label character varying(200) NOT NULL,
    field_type integer NOT NULL,
    required boolean NOT NULL,
    visible boolean NOT NULL,
    choices character varying(1000) NOT NULL,
    "default" character varying(2000) NOT NULL,
    placeholder_text character varying(100) NOT NULL,
    help_text character varying(100) NOT NULL,
    form_id integer NOT NULL
);


ALTER TABLE public.forms_field OWNER TO amarin;

--
-- Name: forms_field_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.forms_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forms_field_id_seq OWNER TO amarin;

--
-- Name: forms_field_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.forms_field_id_seq OWNED BY public.forms_field.id;


--
-- Name: forms_fieldentry; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.forms_fieldentry (
    id integer NOT NULL,
    field_id integer NOT NULL,
    value character varying(2000),
    entry_id integer NOT NULL
);


ALTER TABLE public.forms_fieldentry OWNER TO amarin;

--
-- Name: forms_fieldentry_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.forms_fieldentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forms_fieldentry_id_seq OWNER TO amarin;

--
-- Name: forms_fieldentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.forms_fieldentry_id_seq OWNED BY public.forms_fieldentry.id;


--
-- Name: forms_form; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.forms_form (
    page_ptr_id integer NOT NULL,
    content text NOT NULL,
    button_text character varying(50) NOT NULL,
    response text NOT NULL,
    send_email boolean NOT NULL,
    email_from character varying(254) NOT NULL,
    email_copies character varying(200) NOT NULL,
    email_subject character varying(200) NOT NULL,
    email_message text NOT NULL
);


ALTER TABLE public.forms_form OWNER TO amarin;

--
-- Name: forms_formentry; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.forms_formentry (
    id integer NOT NULL,
    entry_time timestamp with time zone NOT NULL,
    form_id integer NOT NULL
);


ALTER TABLE public.forms_formentry OWNER TO amarin;

--
-- Name: forms_formentry_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.forms_formentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forms_formentry_id_seq OWNER TO amarin;

--
-- Name: forms_formentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.forms_formentry_id_seq OWNED BY public.forms_formentry.id;


--
-- Name: galleries_gallery; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.galleries_gallery (
    page_ptr_id integer NOT NULL,
    content text NOT NULL,
    zip_import character varying(100) NOT NULL
);


ALTER TABLE public.galleries_gallery OWNER TO amarin;

--
-- Name: galleries_galleryimage; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.galleries_galleryimage (
    id integer NOT NULL,
    _order integer,
    file character varying(200) NOT NULL,
    description character varying(1000) NOT NULL,
    gallery_id integer NOT NULL
);


ALTER TABLE public.galleries_galleryimage OWNER TO amarin;

--
-- Name: galleries_galleryimage_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.galleries_galleryimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.galleries_galleryimage_id_seq OWNER TO amarin;

--
-- Name: galleries_galleryimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.galleries_galleryimage_id_seq OWNED BY public.galleries_galleryimage.id;


--
-- Name: generic_assignedkeyword; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.generic_assignedkeyword (
    id integer NOT NULL,
    _order integer,
    object_pk integer NOT NULL,
    content_type_id integer NOT NULL,
    keyword_id integer NOT NULL
);


ALTER TABLE public.generic_assignedkeyword OWNER TO amarin;

--
-- Name: generic_assignedkeyword_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.generic_assignedkeyword_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.generic_assignedkeyword_id_seq OWNER TO amarin;

--
-- Name: generic_assignedkeyword_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.generic_assignedkeyword_id_seq OWNED BY public.generic_assignedkeyword.id;


--
-- Name: generic_keyword; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.generic_keyword (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    site_id integer NOT NULL
);


ALTER TABLE public.generic_keyword OWNER TO amarin;

--
-- Name: generic_keyword_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.generic_keyword_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.generic_keyword_id_seq OWNER TO amarin;

--
-- Name: generic_keyword_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.generic_keyword_id_seq OWNED BY public.generic_keyword.id;


--
-- Name: generic_rating; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.generic_rating (
    id integer NOT NULL,
    value integer NOT NULL,
    rating_date timestamp with time zone,
    object_pk integer NOT NULL,
    content_type_id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.generic_rating OWNER TO amarin;

--
-- Name: generic_rating_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.generic_rating_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.generic_rating_id_seq OWNER TO amarin;

--
-- Name: generic_rating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.generic_rating_id_seq OWNED BY public.generic_rating.id;


--
-- Name: generic_threadedcomment; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.generic_threadedcomment (
    comment_ptr_id integer NOT NULL,
    rating_count integer NOT NULL,
    rating_sum integer NOT NULL,
    rating_average double precision NOT NULL,
    by_author boolean NOT NULL,
    replied_to_id integer
);


ALTER TABLE public.generic_threadedcomment OWNER TO amarin;

--
-- Name: jobaccomplishment; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.jobaccomplishment (
    id integer NOT NULL,
    description text NOT NULL,
    "order" integer NOT NULL,
    job_id integer NOT NULL
);


ALTER TABLE public.jobaccomplishment OWNER TO amarin;

--
-- Name: jobaccomplishment_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.jobaccomplishment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobaccomplishment_id_seq OWNER TO amarin;

--
-- Name: jobaccomplishment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.jobaccomplishment_id_seq OWNED BY public.jobaccomplishment.id;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.jobs (
    id integer NOT NULL,
    company character varying(250) NOT NULL,
    companyurl character varying(200) NOT NULL,
    location character varying(250) NOT NULL,
    title character varying(250) NOT NULL,
    description text NOT NULL,
    start_date date,
    end_date date,
    is_current boolean NOT NULL,
    is_public boolean NOT NULL,
    company_image character varying(250) NOT NULL
);


ALTER TABLE public.jobs OWNER TO amarin;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobs_id_seq OWNER TO amarin;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: pages_link; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.pages_link (
    page_ptr_id integer NOT NULL
);


ALTER TABLE public.pages_link OWNER TO amarin;

--
-- Name: pages_page; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.pages_page (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    _order integer,
    in_menus character varying(100),
    titles character varying(1000),
    content_model character varying(50),
    login_required boolean NOT NULL,
    parent_id integer,
    site_id integer NOT NULL
);


ALTER TABLE public.pages_page OWNER TO amarin;

--
-- Name: pages_page_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.pages_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pages_page_id_seq OWNER TO amarin;

--
-- Name: pages_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.pages_page_id_seq OWNED BY public.pages_page.id;


--
-- Name: pages_richtextpage; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.pages_richtextpage (
    page_ptr_id integer NOT NULL,
    content text NOT NULL
);


ALTER TABLE public.pages_richtextpage OWNER TO amarin;

--
-- Name: programminglanguage; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.programminglanguage (
    id integer NOT NULL,
    name character varying(250) NOT NULL,
    level integer NOT NULL,
    "order" integer NOT NULL,
    description character varying(50) NOT NULL,
    programmingarea_id integer NOT NULL
);


ALTER TABLE public.programminglanguage OWNER TO amarin;

--
-- Name: programminglanguage_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.programminglanguage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.programminglanguage_id_seq OWNER TO amarin;

--
-- Name: programminglanguage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.programminglanguage_id_seq OWNED BY public.programminglanguage.id;


--
-- Name: publications; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.publications (
    id integer NOT NULL,
    title character varying(250) NOT NULL,
    authors text NOT NULL,
    author_underlined character varying(50) NOT NULL,
    journal character varying(150) NOT NULL,
    year integer NOT NULL,
    "order" integer NOT NULL,
    journalpages text NOT NULL,
    link character varying(200) NOT NULL
);


ALTER TABLE public.publications OWNER TO amarin;

--
-- Name: publications_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.publications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.publications_id_seq OWNER TO amarin;

--
-- Name: publications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.publications_id_seq OWNED BY public.publications.id;


--
-- Name: resume_education; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.resume_education (
    id integer NOT NULL,
    name character varying(250) NOT NULL,
    location character varying(250) NOT NULL,
    schoolurl character varying(200) NOT NULL,
    start_date date,
    end_date date,
    degree text NOT NULL,
    description text NOT NULL,
    location2 character varying(250) NOT NULL,
    schoolurl2 character varying(200) NOT NULL,
    name2 character varying(250) NOT NULL
);


ALTER TABLE public.resume_education OWNER TO amarin;

--
-- Name: resume_education_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.resume_education_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resume_education_id_seq OWNER TO amarin;

--
-- Name: resume_education_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.resume_education_id_seq OWNED BY public.resume_education.id;


--
-- Name: resume_language; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.resume_language (
    id integer NOT NULL,
    language character varying(20) NOT NULL,
    level integer NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE public.resume_language OWNER TO amarin;

--
-- Name: resume_language_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.resume_language_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resume_language_id_seq OWNER TO amarin;

--
-- Name: resume_language_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.resume_language_id_seq OWNED BY public.resume_language.id;


--
-- Name: resume_overview; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.resume_overview (
    id integer NOT NULL,
    text text NOT NULL
);


ALTER TABLE public.resume_overview OWNER TO amarin;

--
-- Name: resume_overview_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.resume_overview_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resume_overview_id_seq OWNER TO amarin;

--
-- Name: resume_overview_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.resume_overview_id_seq OWNED BY public.resume_overview.id;


--
-- Name: resume_personalinfo; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.resume_personalinfo (
    id integer NOT NULL,
    first_name character varying(255) NOT NULL,
    middle_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    locality character varying(255) NOT NULL,
    region character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    email character varying(254) NOT NULL,
    linkedin character varying(200) NOT NULL,
    facebook character varying(200) NOT NULL,
    github character varying(200) NOT NULL,
    site character varying(200) NOT NULL,
    twittername character varying(100) NOT NULL,
    suffix character varying(255) NOT NULL,
    image character varying(100) NOT NULL,
    cv_pdf character varying(100) NOT NULL
);


ALTER TABLE public.resume_personalinfo OWNER TO amarin;

--
-- Name: resume_personalinfo_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.resume_personalinfo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resume_personalinfo_id_seq OWNER TO amarin;

--
-- Name: resume_personalinfo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.resume_personalinfo_id_seq OWNED BY public.resume_personalinfo.id;


--
-- Name: resume_programmingarea; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.resume_programmingarea (
    id integer NOT NULL,
    name character varying(250) NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE public.resume_programmingarea OWNER TO amarin;

--
-- Name: resume_programmingarea_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.resume_programmingarea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resume_programmingarea_id_seq OWNER TO amarin;

--
-- Name: resume_programmingarea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.resume_programmingarea_id_seq OWNED BY public.resume_programmingarea.id;


--
-- Name: resume_project; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.resume_project (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    link character varying(200) NOT NULL,
    "order" integer NOT NULL,
    projtype_id integer NOT NULL,
    image character varying(100) NOT NULL,
    long_description text NOT NULL,
    short_description text NOT NULL
);


ALTER TABLE public.resume_project OWNER TO amarin;

--
-- Name: resume_project_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.resume_project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resume_project_id_seq OWNER TO amarin;

--
-- Name: resume_project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.resume_project_id_seq OWNED BY public.resume_project.id;


--
-- Name: resume_projecttype; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.resume_projecttype (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE public.resume_projecttype OWNER TO amarin;

--
-- Name: resume_projecttype_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.resume_projecttype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resume_projecttype_id_seq OWNER TO amarin;

--
-- Name: resume_projecttype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.resume_projecttype_id_seq OWNED BY public.resume_projecttype.id;


--
-- Name: resume_skill; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.resume_skill (
    id integer NOT NULL,
    text text NOT NULL,
    skillset_id integer NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE public.resume_skill OWNER TO amarin;

--
-- Name: resume_skill_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.resume_skill_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resume_skill_id_seq OWNER TO amarin;

--
-- Name: resume_skill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.resume_skill_id_seq OWNED BY public.resume_skill.id;


--
-- Name: resume_skillset; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.resume_skillset (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.resume_skillset OWNER TO amarin;

--
-- Name: resume_skillset_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.resume_skillset_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resume_skillset_id_seq OWNER TO amarin;

--
-- Name: resume_skillset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.resume_skillset_id_seq OWNED BY public.resume_skillset.id;


--
-- Name: twitter_query; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.twitter_query (
    id integer NOT NULL,
    type character varying(10) NOT NULL,
    value character varying(140) NOT NULL,
    interested boolean NOT NULL
);


ALTER TABLE public.twitter_query OWNER TO amarin;

--
-- Name: twitter_query_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.twitter_query_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.twitter_query_id_seq OWNER TO amarin;

--
-- Name: twitter_query_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.twitter_query_id_seq OWNED BY public.twitter_query.id;


--
-- Name: twitter_tweet; Type: TABLE; Schema: public; Owner: amarin; Tablespace: 
--

CREATE TABLE public.twitter_tweet (
    id integer NOT NULL,
    remote_id character varying(50) NOT NULL,
    created_at timestamp with time zone,
    text text,
    profile_image_url character varying(200),
    user_name character varying(100),
    full_name character varying(100),
    retweeter_profile_image_url character varying(200),
    retweeter_user_name character varying(100),
    retweeter_full_name character varying(100),
    query_id integer NOT NULL
);


ALTER TABLE public.twitter_tweet OWNER TO amarin;

--
-- Name: twitter_tweet_id_seq; Type: SEQUENCE; Schema: public; Owner: amarin
--

CREATE SEQUENCE public.twitter_tweet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.twitter_tweet_id_seq OWNER TO amarin;

--
-- Name: twitter_tweet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: amarin
--

ALTER SEQUENCE public.twitter_tweet_id_seq OWNED BY public.twitter_tweet.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.achievement ALTER COLUMN id SET DEFAULT nextval('public.achievement_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogcategory ALTER COLUMN id SET DEFAULT nextval('public.blog_blogcategory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogpost ALTER COLUMN id SET DEFAULT nextval('public.blog_blogpost_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogpost_categories ALTER COLUMN id SET DEFAULT nextval('public.blog_blogpost_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogpost_related_posts ALTER COLUMN id SET DEFAULT nextval('public.blog_blogpost_related_posts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.categories_category ALTER COLUMN id SET DEFAULT nextval('public.categories_category_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.categories_categoryrelation ALTER COLUMN id SET DEFAULT nextval('public.categories_categoryrelation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.conf_setting ALTER COLUMN id SET DEFAULT nextval('public.conf_setting_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.core_sitepermission ALTER COLUMN id SET DEFAULT nextval('public.core_sitepermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.core_sitepermission_sites ALTER COLUMN id SET DEFAULT nextval('public.core_sitepermission_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_comment_flags ALTER COLUMN id SET DEFAULT nextval('public.django_comment_flags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_comments ALTER COLUMN id SET DEFAULT nextval('public.django_comments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_redirect ALTER COLUMN id SET DEFAULT nextval('public.django_redirect_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.forms_field ALTER COLUMN id SET DEFAULT nextval('public.forms_field_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.forms_fieldentry ALTER COLUMN id SET DEFAULT nextval('public.forms_fieldentry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.forms_formentry ALTER COLUMN id SET DEFAULT nextval('public.forms_formentry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.galleries_galleryimage ALTER COLUMN id SET DEFAULT nextval('public.galleries_galleryimage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_assignedkeyword ALTER COLUMN id SET DEFAULT nextval('public.generic_assignedkeyword_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_keyword ALTER COLUMN id SET DEFAULT nextval('public.generic_keyword_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_rating ALTER COLUMN id SET DEFAULT nextval('public.generic_rating_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.jobaccomplishment ALTER COLUMN id SET DEFAULT nextval('public.jobaccomplishment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.pages_page ALTER COLUMN id SET DEFAULT nextval('public.pages_page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.programminglanguage ALTER COLUMN id SET DEFAULT nextval('public.programminglanguage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.publications ALTER COLUMN id SET DEFAULT nextval('public.publications_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_education ALTER COLUMN id SET DEFAULT nextval('public.resume_education_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_language ALTER COLUMN id SET DEFAULT nextval('public.resume_language_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_overview ALTER COLUMN id SET DEFAULT nextval('public.resume_overview_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_personalinfo ALTER COLUMN id SET DEFAULT nextval('public.resume_personalinfo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_programmingarea ALTER COLUMN id SET DEFAULT nextval('public.resume_programmingarea_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_project ALTER COLUMN id SET DEFAULT nextval('public.resume_project_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_projecttype ALTER COLUMN id SET DEFAULT nextval('public.resume_projecttype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_skill ALTER COLUMN id SET DEFAULT nextval('public.resume_skill_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_skillset ALTER COLUMN id SET DEFAULT nextval('public.resume_skillset_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.twitter_query ALTER COLUMN id SET DEFAULT nextval('public.twitter_query_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.twitter_tweet ALTER COLUMN id SET DEFAULT nextval('public.twitter_tweet_id_seq'::regclass);


--
-- Data for Name: achievement; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.achievement (id, description, "order", url, title) FROM stdin;
\.
COPY public.achievement (id, description, "order", url, title) FROM '$$PATH$$/2655.dat';

--
-- Name: achievement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.achievement_id_seq', 7, true);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/2595.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/2597.dat';

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/2593.dat';

--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 136, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/2599.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/2601.dat';

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 2, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/2603.dat';

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: blog_blogcategory; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.blog_blogcategory (id, title, slug, site_id) FROM stdin;
\.
COPY public.blog_blogcategory (id, title, slug, site_id) FROM '$$PATH$$/2609.dat';

--
-- Name: blog_blogcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.blog_blogcategory_id_seq', 1, false);


--
-- Data for Name: blog_blogpost; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.blog_blogpost (id, comments_count, keywords_string, rating_count, rating_sum, rating_average, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, allow_comments, featured_image, site_id, user_id) FROM stdin;
\.
COPY public.blog_blogpost (id, comments_count, keywords_string, rating_count, rating_sum, rating_average, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, allow_comments, featured_image, site_id, user_id) FROM '$$PATH$$/2611.dat';

--
-- Data for Name: blog_blogpost_categories; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.blog_blogpost_categories (id, blogpost_id, blogcategory_id) FROM stdin;
\.
COPY public.blog_blogpost_categories (id, blogpost_id, blogcategory_id) FROM '$$PATH$$/2613.dat';

--
-- Name: blog_blogpost_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.blog_blogpost_categories_id_seq', 1, false);


--
-- Name: blog_blogpost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.blog_blogpost_id_seq', 1, true);


--
-- Data for Name: blog_blogpost_related_posts; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.blog_blogpost_related_posts (id, from_blogpost_id, to_blogpost_id) FROM stdin;
\.
COPY public.blog_blogpost_related_posts (id, from_blogpost_id, to_blogpost_id) FROM '$$PATH$$/2615.dat';

--
-- Name: blog_blogpost_related_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.blog_blogpost_related_posts_id_seq', 1, false);


--
-- Data for Name: categories_category; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.categories_category (id, name, slug, active, thumbnail, thumbnail_width, thumbnail_height, "order", alternate_title, alternate_url, description, meta_keywords, meta_extra, lft, rght, tree_id, level, parent_id) FROM stdin;
\.
COPY public.categories_category (id, name, slug, active, thumbnail, thumbnail_width, thumbnail_height, "order", alternate_title, alternate_url, description, meta_keywords, meta_extra, lft, rght, tree_id, level, parent_id) FROM '$$PATH$$/2683.dat';

--
-- Name: categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.categories_category_id_seq', 9, true);


--
-- Data for Name: categories_categoryrelation; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.categories_categoryrelation (id, object_id, relation_type, category_id, content_type_id) FROM stdin;
\.
COPY public.categories_categoryrelation (id, object_id, relation_type, category_id, content_type_id) FROM '$$PATH$$/2685.dat';

--
-- Name: categories_categoryrelation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.categories_categoryrelation_id_seq', 1, false);


--
-- Data for Name: conf_setting; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.conf_setting (id, name, value, site_id) FROM stdin;
\.
COPY public.conf_setting (id, name, value, site_id) FROM '$$PATH$$/2617.dat';

--
-- Name: conf_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.conf_setting_id_seq', 28, true);


--
-- Data for Name: core_sitepermission; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.core_sitepermission (id, user_id) FROM stdin;
\.
COPY public.core_sitepermission (id, user_id) FROM '$$PATH$$/2619.dat';

--
-- Name: core_sitepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.core_sitepermission_id_seq', 1, false);


--
-- Data for Name: core_sitepermission_sites; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.core_sitepermission_sites (id, sitepermission_id, site_id) FROM stdin;
\.
COPY public.core_sitepermission_sites (id, sitepermission_id, site_id) FROM '$$PATH$$/2621.dat';

--
-- Name: core_sitepermission_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.core_sitepermission_sites_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/2605.dat';

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 103, true);


--
-- Data for Name: django_comment_flags; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.django_comment_flags (id, flag, flag_date, comment_id, user_id) FROM stdin;
\.
COPY public.django_comment_flags (id, flag, flag_date, comment_id, user_id) FROM '$$PATH$$/2625.dat';

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.django_comment_flags_id_seq', 1, false);


--
-- Data for Name: django_comments; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.django_comments (id, object_pk, user_name, user_email, user_url, comment, submit_date, ip_address, is_public, is_removed, content_type_id, site_id, user_id) FROM stdin;
\.
COPY public.django_comments (id, object_pk, user_name, user_email, user_url, comment, submit_date, ip_address, is_public, is_removed, content_type_id, site_id, user_id) FROM '$$PATH$$/2623.dat';

--
-- Name: django_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.django_comments_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/2591.dat';

--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 45, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/2589.dat';

--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 78, true);


--
-- Data for Name: django_redirect; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.django_redirect (id, site_id, old_path, new_path) FROM stdin;
\.
COPY public.django_redirect (id, site_id, old_path, new_path) FROM '$$PATH$$/2648.dat';

--
-- Name: django_redirect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.django_redirect_id_seq', 2, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/2649.dat';

--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.django_site (id, domain, name) FROM stdin;
\.
COPY public.django_site (id, domain, name) FROM '$$PATH$$/2607.dat';

--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Data for Name: forms_field; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.forms_field (id, _order, label, field_type, required, visible, choices, "default", placeholder_text, help_text, form_id) FROM stdin;
\.
COPY public.forms_field (id, _order, label, field_type, required, visible, choices, "default", placeholder_text, help_text, form_id) FROM '$$PATH$$/2631.dat';

--
-- Name: forms_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.forms_field_id_seq', 1, false);


--
-- Data for Name: forms_fieldentry; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.forms_fieldentry (id, field_id, value, entry_id) FROM stdin;
\.
COPY public.forms_fieldentry (id, field_id, value, entry_id) FROM '$$PATH$$/2633.dat';

--
-- Name: forms_fieldentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.forms_fieldentry_id_seq', 1, false);


--
-- Data for Name: forms_form; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.forms_form (page_ptr_id, content, button_text, response, send_email, email_from, email_copies, email_subject, email_message) FROM stdin;
\.
COPY public.forms_form (page_ptr_id, content, button_text, response, send_email, email_from, email_copies, email_subject, email_message) FROM '$$PATH$$/2634.dat';

--
-- Data for Name: forms_formentry; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.forms_formentry (id, entry_time, form_id) FROM stdin;
\.
COPY public.forms_formentry (id, entry_time, form_id) FROM '$$PATH$$/2636.dat';

--
-- Name: forms_formentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.forms_formentry_id_seq', 1, false);


--
-- Data for Name: galleries_gallery; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.galleries_gallery (page_ptr_id, content, zip_import) FROM stdin;
\.
COPY public.galleries_gallery (page_ptr_id, content, zip_import) FROM '$$PATH$$/2637.dat';

--
-- Data for Name: galleries_galleryimage; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.galleries_galleryimage (id, _order, file, description, gallery_id) FROM stdin;
\.
COPY public.galleries_galleryimage (id, _order, file, description, gallery_id) FROM '$$PATH$$/2639.dat';

--
-- Name: galleries_galleryimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.galleries_galleryimage_id_seq', 5, true);


--
-- Data for Name: generic_assignedkeyword; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.generic_assignedkeyword (id, _order, object_pk, content_type_id, keyword_id) FROM stdin;
\.
COPY public.generic_assignedkeyword (id, _order, object_pk, content_type_id, keyword_id) FROM '$$PATH$$/2641.dat';

--
-- Name: generic_assignedkeyword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.generic_assignedkeyword_id_seq', 3, true);


--
-- Data for Name: generic_keyword; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.generic_keyword (id, title, slug, site_id) FROM stdin;
\.
COPY public.generic_keyword (id, title, slug, site_id) FROM '$$PATH$$/2643.dat';

--
-- Name: generic_keyword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.generic_keyword_id_seq', 1, true);


--
-- Data for Name: generic_rating; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.generic_rating (id, value, rating_date, object_pk, content_type_id, user_id) FROM stdin;
\.
COPY public.generic_rating (id, value, rating_date, object_pk, content_type_id, user_id) FROM '$$PATH$$/2645.dat';

--
-- Name: generic_rating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.generic_rating_id_seq', 1, false);


--
-- Data for Name: generic_threadedcomment; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.generic_threadedcomment (comment_ptr_id, rating_count, rating_sum, rating_average, by_author, replied_to_id) FROM stdin;
\.
COPY public.generic_threadedcomment (comment_ptr_id, rating_count, rating_sum, rating_average, by_author, replied_to_id) FROM '$$PATH$$/2646.dat';

--
-- Data for Name: jobaccomplishment; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.jobaccomplishment (id, description, "order", job_id) FROM stdin;
\.
COPY public.jobaccomplishment (id, description, "order", job_id) FROM '$$PATH$$/2661.dat';

--
-- Name: jobaccomplishment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.jobaccomplishment_id_seq', 13, true);


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.jobs (id, company, companyurl, location, title, description, start_date, end_date, is_current, is_public, company_image) FROM stdin;
\.
COPY public.jobs (id, company, companyurl, location, title, description, start_date, end_date, is_current, is_public, company_image) FROM '$$PATH$$/2659.dat';

--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.jobs_id_seq', 4, true);


--
-- Data for Name: pages_link; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.pages_link (page_ptr_id) FROM stdin;
\.
COPY public.pages_link (page_ptr_id) FROM '$$PATH$$/2628.dat';

--
-- Data for Name: pages_page; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.pages_page (id, keywords_string, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, _order, in_menus, titles, content_model, login_required, parent_id, site_id) FROM stdin;
\.
COPY public.pages_page (id, keywords_string, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, _order, in_menus, titles, content_model, login_required, parent_id, site_id) FROM '$$PATH$$/2627.dat';

--
-- Name: pages_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.pages_page_id_seq', 10, true);


--
-- Data for Name: pages_richtextpage; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.pages_richtextpage (page_ptr_id, content) FROM stdin;
\.
COPY public.pages_richtextpage (page_ptr_id, content) FROM '$$PATH$$/2629.dat';

--
-- Data for Name: programminglanguage; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.programminglanguage (id, name, level, "order", description, programmingarea_id) FROM stdin;
\.
COPY public.programminglanguage (id, name, level, "order", description, programmingarea_id) FROM '$$PATH$$/2669.dat';

--
-- Name: programminglanguage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.programminglanguage_id_seq', 24, true);


--
-- Data for Name: publications; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.publications (id, title, authors, author_underlined, journal, year, "order", journalpages, link) FROM stdin;
\.
COPY public.publications (id, title, authors, author_underlined, journal, year, "order", journalpages, link) FROM '$$PATH$$/2677.dat';

--
-- Name: publications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.publications_id_seq', 7, true);


--
-- Data for Name: resume_education; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.resume_education (id, name, location, schoolurl, start_date, end_date, degree, description, location2, schoolurl2, name2) FROM stdin;
\.
COPY public.resume_education (id, name, location, schoolurl, start_date, end_date, degree, description, location2, schoolurl2, name2) FROM '$$PATH$$/2657.dat';

--
-- Name: resume_education_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.resume_education_id_seq', 3, true);


--
-- Data for Name: resume_language; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.resume_language (id, language, level, "order") FROM stdin;
\.
COPY public.resume_language (id, language, level, "order") FROM '$$PATH$$/2663.dat';

--
-- Name: resume_language_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.resume_language_id_seq', 10, true);


--
-- Data for Name: resume_overview; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.resume_overview (id, text) FROM stdin;
\.
COPY public.resume_overview (id, text) FROM '$$PATH$$/2665.dat';

--
-- Name: resume_overview_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.resume_overview_id_seq', 1, true);


--
-- Data for Name: resume_personalinfo; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.resume_personalinfo (id, first_name, middle_name, last_name, locality, region, title, email, linkedin, facebook, github, site, twittername, suffix, image, cv_pdf) FROM stdin;
\.
COPY public.resume_personalinfo (id, first_name, middle_name, last_name, locality, region, title, email, linkedin, facebook, github, site, twittername, suffix, image, cv_pdf) FROM '$$PATH$$/2667.dat';

--
-- Name: resume_personalinfo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.resume_personalinfo_id_seq', 1, true);


--
-- Data for Name: resume_programmingarea; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.resume_programmingarea (id, name, "order") FROM stdin;
\.
COPY public.resume_programmingarea (id, name, "order") FROM '$$PATH$$/2679.dat';

--
-- Name: resume_programmingarea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.resume_programmingarea_id_seq', 3, true);


--
-- Data for Name: resume_project; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.resume_project (id, name, link, "order", projtype_id, image, long_description, short_description) FROM stdin;
\.
COPY public.resume_project (id, name, link, "order", projtype_id, image, long_description, short_description) FROM '$$PATH$$/2675.dat';

--
-- Name: resume_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.resume_project_id_seq', 14, true);


--
-- Data for Name: resume_projecttype; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.resume_projecttype (id, name, "order") FROM stdin;
\.
COPY public.resume_projecttype (id, name, "order") FROM '$$PATH$$/2681.dat';

--
-- Name: resume_projecttype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.resume_projecttype_id_seq', 2, true);


--
-- Data for Name: resume_skill; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.resume_skill (id, text, skillset_id, "order") FROM stdin;
\.
COPY public.resume_skill (id, text, skillset_id, "order") FROM '$$PATH$$/2671.dat';

--
-- Name: resume_skill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.resume_skill_id_seq', 13, true);


--
-- Data for Name: resume_skillset; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.resume_skillset (id, name) FROM stdin;
\.
COPY public.resume_skillset (id, name) FROM '$$PATH$$/2673.dat';

--
-- Name: resume_skillset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.resume_skillset_id_seq', 2, true);


--
-- Data for Name: twitter_query; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.twitter_query (id, type, value, interested) FROM stdin;
\.
COPY public.twitter_query (id, type, value, interested) FROM '$$PATH$$/2651.dat';

--
-- Name: twitter_query_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.twitter_query_id_seq', 1, true);


--
-- Data for Name: twitter_tweet; Type: TABLE DATA; Schema: public; Owner: amarin
--

COPY public.twitter_tweet (id, remote_id, created_at, text, profile_image_url, user_name, full_name, retweeter_profile_image_url, retweeter_user_name, retweeter_full_name, query_id) FROM stdin;
\.
COPY public.twitter_tweet (id, remote_id, created_at, text, profile_image_url, user_name, full_name, retweeter_profile_image_url, retweeter_user_name, retweeter_full_name, query_id) FROM '$$PATH$$/2653.dat';

--
-- Name: twitter_tweet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: amarin
--

SELECT pg_catalog.setval('public.twitter_tweet_id_seq', 1, false);


--
-- Name: achievement_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.achievement
    ADD CONSTRAINT achievement_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: blog_blogcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.blog_blogcategory
    ADD CONSTRAINT blog_blogcategory_pkey PRIMARY KEY (id);


--
-- Name: blog_blogpost_categories_blogpost_id_a64d32c5_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost_categories_blogpost_id_a64d32c5_uniq UNIQUE (blogpost_id, blogcategory_id);


--
-- Name: blog_blogpost_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_blogpost_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.blog_blogpost
    ADD CONSTRAINT blog_blogpost_pkey PRIMARY KEY (id);


--
-- Name: blog_blogpost_related_posts_from_blogpost_id_3bd0f49f_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_related_posts_from_blogpost_id_3bd0f49f_uniq UNIQUE (from_blogpost_id, to_blogpost_id);


--
-- Name: blog_blogpost_related_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_related_posts_pkey PRIMARY KEY (id);


--
-- Name: categories_category_parent_id_893f7987_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.categories_category
    ADD CONSTRAINT categories_category_parent_id_893f7987_uniq UNIQUE (parent_id, name);


--
-- Name: categories_category_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.categories_category
    ADD CONSTRAINT categories_category_pkey PRIMARY KEY (id);


--
-- Name: categories_categoryrelation_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.categories_categoryrelation
    ADD CONSTRAINT categories_categoryrelation_pkey PRIMARY KEY (id);


--
-- Name: conf_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.conf_setting
    ADD CONSTRAINT conf_setting_pkey PRIMARY KEY (id);


--
-- Name: core_sitepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.core_sitepermission
    ADD CONSTRAINT core_sitepermission_pkey PRIMARY KEY (id);


--
-- Name: core_sitepermission_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.core_sitepermission_sites
    ADD CONSTRAINT core_sitepermission_sites_pkey PRIMARY KEY (id);


--
-- Name: core_sitepermission_sites_sitepermission_id_e3e7353a_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.core_sitepermission_sites
    ADD CONSTRAINT core_sitepermission_sites_sitepermission_id_e3e7353a_uniq UNIQUE (sitepermission_id, site_id);


--
-- Name: core_sitepermission_user_id_key; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.core_sitepermission
    ADD CONSTRAINT core_sitepermission_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags_user_id_537f77a7_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_537f77a7_uniq UNIQUE (user_id, comment_id, flag);


--
-- Name: django_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_redirect_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_redirect
    ADD CONSTRAINT django_redirect_pkey PRIMARY KEY (id);


--
-- Name: django_redirect_site_id_ac5dd16b_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_redirect
    ADD CONSTRAINT django_redirect_site_id_ac5dd16b_uniq UNIQUE (site_id, old_path);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: forms_field_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.forms_field
    ADD CONSTRAINT forms_field_pkey PRIMARY KEY (id);


--
-- Name: forms_fieldentry_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.forms_fieldentry
    ADD CONSTRAINT forms_fieldentry_pkey PRIMARY KEY (id);


--
-- Name: forms_form_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.forms_form
    ADD CONSTRAINT forms_form_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: forms_formentry_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.forms_formentry
    ADD CONSTRAINT forms_formentry_pkey PRIMARY KEY (id);


--
-- Name: galleries_gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.galleries_gallery
    ADD CONSTRAINT galleries_gallery_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: galleries_galleryimage_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.galleries_galleryimage
    ADD CONSTRAINT galleries_galleryimage_pkey PRIMARY KEY (id);


--
-- Name: generic_assignedkeyword_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.generic_assignedkeyword
    ADD CONSTRAINT generic_assignedkeyword_pkey PRIMARY KEY (id);


--
-- Name: generic_keyword_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.generic_keyword
    ADD CONSTRAINT generic_keyword_pkey PRIMARY KEY (id);


--
-- Name: generic_rating_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.generic_rating
    ADD CONSTRAINT generic_rating_pkey PRIMARY KEY (id);


--
-- Name: generic_threadedcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.generic_threadedcomment
    ADD CONSTRAINT generic_threadedcomment_pkey PRIMARY KEY (comment_ptr_id);


--
-- Name: jobaccomplishment_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.jobaccomplishment
    ADD CONSTRAINT jobaccomplishment_pkey PRIMARY KEY (id);


--
-- Name: jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: pages_link_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.pages_link
    ADD CONSTRAINT pages_link_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: pages_page_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.pages_page
    ADD CONSTRAINT pages_page_pkey PRIMARY KEY (id);


--
-- Name: pages_richtextpage_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.pages_richtextpage
    ADD CONSTRAINT pages_richtextpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: programminglanguage_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.programminglanguage
    ADD CONSTRAINT programminglanguage_pkey PRIMARY KEY (id);


--
-- Name: publications_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publications_pkey PRIMARY KEY (id);


--
-- Name: resume_education_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.resume_education
    ADD CONSTRAINT resume_education_pkey PRIMARY KEY (id);


--
-- Name: resume_language_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.resume_language
    ADD CONSTRAINT resume_language_pkey PRIMARY KEY (id);


--
-- Name: resume_overview_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.resume_overview
    ADD CONSTRAINT resume_overview_pkey PRIMARY KEY (id);


--
-- Name: resume_personalinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.resume_personalinfo
    ADD CONSTRAINT resume_personalinfo_pkey PRIMARY KEY (id);


--
-- Name: resume_programmingarea_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.resume_programmingarea
    ADD CONSTRAINT resume_programmingarea_pkey PRIMARY KEY (id);


--
-- Name: resume_project_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.resume_project
    ADD CONSTRAINT resume_project_pkey PRIMARY KEY (id);


--
-- Name: resume_projecttype_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.resume_projecttype
    ADD CONSTRAINT resume_projecttype_pkey PRIMARY KEY (id);


--
-- Name: resume_skill_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.resume_skill
    ADD CONSTRAINT resume_skill_pkey PRIMARY KEY (id);


--
-- Name: resume_skillset_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.resume_skillset
    ADD CONSTRAINT resume_skillset_pkey PRIMARY KEY (id);


--
-- Name: twitter_query_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.twitter_query
    ADD CONSTRAINT twitter_query_pkey PRIMARY KEY (id);


--
-- Name: twitter_tweet_pkey; Type: CONSTRAINT; Schema: public; Owner: amarin; Tablespace: 
--

ALTER TABLE ONLY public.twitter_tweet
    ADD CONSTRAINT twitter_tweet_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX auth_user_groups_0e939a4f ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX auth_user_groups_e8701ad4 ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_8373b171 ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: blog_blogcategory_9365d6e7; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX blog_blogcategory_9365d6e7 ON public.blog_blogcategory USING btree (site_id);


--
-- Name: blog_blogpost_9365d6e7; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX blog_blogpost_9365d6e7 ON public.blog_blogpost USING btree (site_id);


--
-- Name: blog_blogpost_categories_53a0aca2; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX blog_blogpost_categories_53a0aca2 ON public.blog_blogpost_categories USING btree (blogpost_id);


--
-- Name: blog_blogpost_categories_efb54956; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX blog_blogpost_categories_efb54956 ON public.blog_blogpost_categories USING btree (blogcategory_id);


--
-- Name: blog_blogpost_e8701ad4; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX blog_blogpost_e8701ad4 ON public.blog_blogpost USING btree (user_id);


--
-- Name: blog_blogpost_publish_date_703abc16_uniq; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX blog_blogpost_publish_date_703abc16_uniq ON public.blog_blogpost USING btree (publish_date);


--
-- Name: blog_blogpost_related_posts_191c4981; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX blog_blogpost_related_posts_191c4981 ON public.blog_blogpost_related_posts USING btree (from_blogpost_id);


--
-- Name: blog_blogpost_related_posts_71f16e58; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX blog_blogpost_related_posts_71f16e58 ON public.blog_blogpost_related_posts USING btree (to_blogpost_id);


--
-- Name: categories_category_2dbcba41; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX categories_category_2dbcba41 ON public.categories_category USING btree (slug);


--
-- Name: categories_category_3cfbd988; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX categories_category_3cfbd988 ON public.categories_category USING btree (rght);


--
-- Name: categories_category_656442a0; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX categories_category_656442a0 ON public.categories_category USING btree (tree_id);


--
-- Name: categories_category_6be37982; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX categories_category_6be37982 ON public.categories_category USING btree (parent_id);


--
-- Name: categories_category_c9e9a848; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX categories_category_c9e9a848 ON public.categories_category USING btree (level);


--
-- Name: categories_category_caf7cc51; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX categories_category_caf7cc51 ON public.categories_category USING btree (lft);


--
-- Name: categories_category_slug_6fddebb1_like; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX categories_category_slug_6fddebb1_like ON public.categories_category USING btree (slug varchar_pattern_ops);


--
-- Name: categories_categoryrelation_417f1b1c; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX categories_categoryrelation_417f1b1c ON public.categories_categoryrelation USING btree (content_type_id);


--
-- Name: categories_categoryrelation_b583a629; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX categories_categoryrelation_b583a629 ON public.categories_categoryrelation USING btree (category_id);


--
-- Name: conf_setting_9365d6e7; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX conf_setting_9365d6e7 ON public.conf_setting USING btree (site_id);


--
-- Name: core_sitepermission_sites_9365d6e7; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX core_sitepermission_sites_9365d6e7 ON public.core_sitepermission_sites USING btree (site_id);


--
-- Name: core_sitepermission_sites_f6687ce4; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX core_sitepermission_sites_f6687ce4 ON public.core_sitepermission_sites USING btree (sitepermission_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_comment_flags_327a6c43; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_comment_flags_327a6c43 ON public.django_comment_flags USING btree (flag);


--
-- Name: django_comment_flags_69b97d17; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_comment_flags_69b97d17 ON public.django_comment_flags USING btree (comment_id);


--
-- Name: django_comment_flags_e8701ad4; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_comment_flags_e8701ad4 ON public.django_comment_flags USING btree (user_id);


--
-- Name: django_comment_flags_flag_8b141fcb_like; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_comment_flags_flag_8b141fcb_like ON public.django_comment_flags USING btree (flag varchar_pattern_ops);


--
-- Name: django_comments_417f1b1c; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_comments_417f1b1c ON public.django_comments USING btree (content_type_id);


--
-- Name: django_comments_9365d6e7; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_comments_9365d6e7 ON public.django_comments USING btree (site_id);


--
-- Name: django_comments_e8701ad4; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_comments_e8701ad4 ON public.django_comments USING btree (user_id);


--
-- Name: django_comments_submit_date_514ed2d9_uniq; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_comments_submit_date_514ed2d9_uniq ON public.django_comments USING btree (submit_date);


--
-- Name: django_redirect_91a0b591; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_redirect_91a0b591 ON public.django_redirect USING btree (old_path);


--
-- Name: django_redirect_9365d6e7; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_redirect_9365d6e7 ON public.django_redirect USING btree (site_id);


--
-- Name: django_redirect_old_path_c6cc94d3_like; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_redirect_old_path_c6cc94d3_like ON public.django_redirect USING btree (old_path varchar_pattern_ops);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: forms_field_d6cba1ad; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX forms_field_d6cba1ad ON public.forms_field USING btree (form_id);


--
-- Name: forms_fieldentry_b64a62ea; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX forms_fieldentry_b64a62ea ON public.forms_fieldentry USING btree (entry_id);


--
-- Name: forms_formentry_d6cba1ad; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX forms_formentry_d6cba1ad ON public.forms_formentry USING btree (form_id);


--
-- Name: galleries_galleryimage_6d994cdb; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX galleries_galleryimage_6d994cdb ON public.galleries_galleryimage USING btree (gallery_id);


--
-- Name: generic_assignedkeyword_417f1b1c; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX generic_assignedkeyword_417f1b1c ON public.generic_assignedkeyword USING btree (content_type_id);


--
-- Name: generic_assignedkeyword_5c003bba; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX generic_assignedkeyword_5c003bba ON public.generic_assignedkeyword USING btree (keyword_id);


--
-- Name: generic_keyword_9365d6e7; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX generic_keyword_9365d6e7 ON public.generic_keyword USING btree (site_id);


--
-- Name: generic_rating_417f1b1c; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX generic_rating_417f1b1c ON public.generic_rating USING btree (content_type_id);


--
-- Name: generic_rating_e8701ad4; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX generic_rating_e8701ad4 ON public.generic_rating USING btree (user_id);


--
-- Name: generic_threadedcomment_21ce1e68; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX generic_threadedcomment_21ce1e68 ON public.generic_threadedcomment USING btree (replied_to_id);


--
-- Name: jobaccomplishment_d697ea38; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX jobaccomplishment_d697ea38 ON public.jobaccomplishment USING btree (job_id);


--
-- Name: pages_page_6be37982; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX pages_page_6be37982 ON public.pages_page USING btree (parent_id);


--
-- Name: pages_page_9365d6e7; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX pages_page_9365d6e7 ON public.pages_page USING btree (site_id);


--
-- Name: pages_page_publish_date_eb7c8d46_uniq; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX pages_page_publish_date_eb7c8d46_uniq ON public.pages_page USING btree (publish_date);


--
-- Name: programminglanguage_51d2fd4b; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX programminglanguage_51d2fd4b ON public.programminglanguage USING btree (programmingarea_id);


--
-- Name: resume_project_68d8cccf; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX resume_project_68d8cccf ON public.resume_project USING btree (projtype_id);


--
-- Name: resume_skill_3b232a2a; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX resume_skill_3b232a2a ON public.resume_skill USING btree (skillset_id);


--
-- Name: twitter_tweet_0bbeda9c; Type: INDEX; Schema: public; Owner: amarin; Tablespace: 
--

CREATE INDEX twitter_tweet_0bbeda9c ON public.twitter_tweet USING btree (query_id);


--
-- Name: ad11d0c1662f6ed6839bc6d43c9ce4f3; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_threadedcomment
    ADD CONSTRAINT ad11d0c1662f6ed6839bc6d43c9ce4f3 FOREIGN KEY (replied_to_id) REFERENCES public.generic_threadedcomment(comment_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogcategory_site_id_42b9c96d_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogcategory
    ADD CONSTRAINT blog_blogcategory_site_id_42b9c96d_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost__blogcategory_id_f6695246_fk_blog_blogcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost__blogcategory_id_f6695246_fk_blog_blogcategory_id FOREIGN KEY (blogcategory_id) REFERENCES public.blog_blogcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_categori_blogpost_id_daeea608_fk_blog_blogpost_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost_categori_blogpost_id_daeea608_fk_blog_blogpost_id FOREIGN KEY (blogpost_id) REFERENCES public.blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_rel_from_blogpost_id_27ea4c18_fk_blog_blogpost_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_rel_from_blogpost_id_27ea4c18_fk_blog_blogpost_id FOREIGN KEY (from_blogpost_id) REFERENCES public.blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_relat_to_blogpost_id_35f7acdd_fk_blog_blogpost_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_relat_to_blogpost_id_35f7acdd_fk_blog_blogpost_id FOREIGN KEY (to_blogpost_id) REFERENCES public.blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_site_id_7995688f_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogpost
    ADD CONSTRAINT blog_blogpost_site_id_7995688f_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_user_id_12ed6b16_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.blog_blogpost
    ADD CONSTRAINT blog_blogpost_user_id_12ed6b16_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: categories_c_content_type_id_f686b696_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.categories_categoryrelation
    ADD CONSTRAINT categories_c_content_type_id_f686b696_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: categories_categ_category_id_e5e686b2_fk_categories_category_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.categories_categoryrelation
    ADD CONSTRAINT categories_categ_category_id_e5e686b2_fk_categories_category_id FOREIGN KEY (category_id) REFERENCES public.categories_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: categories_categor_parent_id_f141de59_fk_categories_category_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.categories_category
    ADD CONSTRAINT categories_categor_parent_id_f141de59_fk_categories_category_id FOREIGN KEY (parent_id) REFERENCES public.categories_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: conf_setting_site_id_b235f7ed_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.conf_setting
    ADD CONSTRAINT conf_setting_site_id_b235f7ed_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sitep_sitepermission_id_d33bc79e_fk_core_sitepermission_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.core_sitepermission_sites
    ADD CONSTRAINT core_sitep_sitepermission_id_d33bc79e_fk_core_sitepermission_id FOREIGN KEY (sitepermission_id) REFERENCES public.core_sitepermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sitepermission_sites_site_id_38038b76_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.core_sitepermission_sites
    ADD CONSTRAINT core_sitepermission_sites_site_id_38038b76_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sitepermission_user_id_0a3cbb11_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.core_sitepermission
    ADD CONSTRAINT core_sitepermission_user_id_0a3cbb11_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comme_content_type_id_c4afe962_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comme_content_type_id_c4afe962_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags_comment_id_d8054933_fk_django_comments_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_comment_id_d8054933_fk_django_comments_id FOREIGN KEY (comment_id) REFERENCES public.django_comments(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags_user_id_f3f81f0a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_f3f81f0a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments_site_id_9dcf666e_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_site_id_9dcf666e_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments_user_id_a0a440a1_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_user_id_a0a440a1_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_redirect_site_id_c3e37341_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.django_redirect
    ADD CONSTRAINT django_redirect_site_id_c3e37341_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forms_field_form_id_9ca5dc7e_fk_forms_form_page_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.forms_field
    ADD CONSTRAINT forms_field_form_id_9ca5dc7e_fk_forms_form_page_ptr_id FOREIGN KEY (form_id) REFERENCES public.forms_form(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forms_fieldentry_entry_id_c4fdc570_fk_forms_formentry_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.forms_fieldentry
    ADD CONSTRAINT forms_fieldentry_entry_id_c4fdc570_fk_forms_formentry_id FOREIGN KEY (entry_id) REFERENCES public.forms_formentry(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forms_form_page_ptr_id_d3bcbf3a_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.forms_form
    ADD CONSTRAINT forms_form_page_ptr_id_d3bcbf3a_fk_pages_page_id FOREIGN KEY (page_ptr_id) REFERENCES public.pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forms_formentry_form_id_d0f23912_fk_forms_form_page_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.forms_formentry
    ADD CONSTRAINT forms_formentry_form_id_d0f23912_fk_forms_form_page_ptr_id FOREIGN KEY (form_id) REFERENCES public.forms_form(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: galleries__gallery_id_af12d3f5_fk_galleries_gallery_page_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.galleries_galleryimage
    ADD CONSTRAINT galleries__gallery_id_af12d3f5_fk_galleries_gallery_page_ptr_id FOREIGN KEY (gallery_id) REFERENCES public.galleries_gallery(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: galleries_gallery_page_ptr_id_8562ba87_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.galleries_gallery
    ADD CONSTRAINT galleries_gallery_page_ptr_id_8562ba87_fk_pages_page_id FOREIGN KEY (page_ptr_id) REFERENCES public.pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_assi_content_type_id_3dd89a7f_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_assignedkeyword
    ADD CONSTRAINT generic_assi_content_type_id_3dd89a7f_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_assignedkeywo_keyword_id_44c17f9d_fk_generic_keyword_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_assignedkeyword
    ADD CONSTRAINT generic_assignedkeywo_keyword_id_44c17f9d_fk_generic_keyword_id FOREIGN KEY (keyword_id) REFERENCES public.generic_keyword(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_keyword_site_id_c5be0acc_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_keyword
    ADD CONSTRAINT generic_keyword_site_id_c5be0acc_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_rati_content_type_id_eaf475fa_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_rating
    ADD CONSTRAINT generic_rati_content_type_id_eaf475fa_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_rating_user_id_60020469_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_rating
    ADD CONSTRAINT generic_rating_user_id_60020469_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_threadedc_comment_ptr_id_e208ed60_fk_django_comments_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.generic_threadedcomment
    ADD CONSTRAINT generic_threadedc_comment_ptr_id_e208ed60_fk_django_comments_id FOREIGN KEY (comment_ptr_id) REFERENCES public.django_comments(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jobaccomplishment_job_id_a04554fd_fk_jobs_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.jobaccomplishment
    ADD CONSTRAINT jobaccomplishment_job_id_a04554fd_fk_jobs_id FOREIGN KEY (job_id) REFERENCES public.jobs(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pages_link_page_ptr_id_37d469f7_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.pages_link
    ADD CONSTRAINT pages_link_page_ptr_id_37d469f7_fk_pages_page_id FOREIGN KEY (page_ptr_id) REFERENCES public.pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pages_page_parent_id_133fa4d3_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.pages_page
    ADD CONSTRAINT pages_page_parent_id_133fa4d3_fk_pages_page_id FOREIGN KEY (parent_id) REFERENCES public.pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pages_page_site_id_47a43e5b_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.pages_page
    ADD CONSTRAINT pages_page_site_id_47a43e5b_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pages_richtextpage_page_ptr_id_8ca99b83_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.pages_richtextpage
    ADD CONSTRAINT pages_richtextpage_page_ptr_id_8ca99b83_fk_pages_page_id FOREIGN KEY (page_ptr_id) REFERENCES public.pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: progra_programmingarea_id_1edf0110_fk_resume_programmingarea_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.programminglanguage
    ADD CONSTRAINT progra_programmingarea_id_1edf0110_fk_resume_programmingarea_id FOREIGN KEY (programmingarea_id) REFERENCES public.resume_programmingarea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: resume_project_projtype_id_36ffa15d_fk_resume_projecttype_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_project
    ADD CONSTRAINT resume_project_projtype_id_36ffa15d_fk_resume_projecttype_id FOREIGN KEY (projtype_id) REFERENCES public.resume_projecttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: resume_skill_skillset_id_c155f55d_fk_resume_skillset_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.resume_skill
    ADD CONSTRAINT resume_skill_skillset_id_c155f55d_fk_resume_skillset_id FOREIGN KEY (skillset_id) REFERENCES public.resume_skillset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: twitter_tweet_query_id_bd42b699_fk_twitter_query_id; Type: FK CONSTRAINT; Schema: public; Owner: amarin
--

ALTER TABLE ONLY public.twitter_tweet
    ADD CONSTRAINT twitter_tweet_query_id_bd42b699_fk_twitter_query_id FOREIGN KEY (query_id) REFERENCES public.twitter_query(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

